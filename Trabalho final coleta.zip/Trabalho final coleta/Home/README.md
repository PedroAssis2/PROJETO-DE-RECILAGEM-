# Landing Page - Trabalho Recicláveis Vila Velha

Este projeto é uma landing page para a empresa "Trabalho Recicláveis Vila Velha", focada em serviços de coleta seletiva e reciclagem.

## Características

- Design responsivo para diferentes tamanhos de tela
- Integração de modelos 3D interativos do Sketchfab
- Estilo visual moderno com cores relacionadas ao tema de meio ambiente e reciclagem
- Efeitos de hover e transições suaves para melhor experiência do usuário
- Compatível com todos os navegadores modernos

## Tecnologias Utilizadas

- HTML5
- CSS3
- Font Awesome (para ícones)
- Sketchfab (para modelos 3D)

## Estrutura de Arquivos

- `index.html` - Estrutura principal da página
- `style.css` - Estilos e layout da página
- `image.png` - Imagem de referência do rascunho original

## Modelos 3D

A página incorpora dois modelos 3D do Sketchfab:

1. **Lixeira de Reciclagem** - Um modelo 3D de uma lixeira de reciclagem para papel
2. **Símbolo de Reciclagem** - Um modelo 3D do símbolo universal de reciclagem

## Como Usar

1. Clone ou baixe este repositório
2. Abra o arquivo `index.html` em qualquer navegador moderno
3. Para modificar o conteúdo, edite o arquivo `index.html`
4. Para modificar o estilo, edite o arquivo `style.css`

## Responsividade

A página foi projetada para ser responsiva e se adaptar a diferentes tamanhos de tela:

- Desktop (acima de 992px)
- Tablet (768px - 992px)
- Celular (abaixo de 768px)
- Celular pequeno (abaixo de 480px)

## Créditos

- Modelos 3D: [Sketchfab](https://sketchfab.com/)
- Ícones: [Font Awesome](https://fontawesome.com/)

